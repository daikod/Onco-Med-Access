--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: medicines; Type: TABLE; Schema: public; Owner: oncology_user
--

CREATE TABLE public.medicines (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    quantity integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.medicines OWNER TO oncology_user;

--
-- Name: medicines_id_seq; Type: SEQUENCE; Schema: public; Owner: oncology_user
--

CREATE SEQUENCE public.medicines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.medicines_id_seq OWNER TO oncology_user;

--
-- Name: medicines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oncology_user
--

ALTER SEQUENCE public.medicines_id_seq OWNED BY public.medicines.id;


--
-- Name: patients; Type: TABLE; Schema: public; Owner: oncology_user
--

CREATE TABLE public.patients (
    id integer NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    date_of_birth date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.patients OWNER TO oncology_user;

--
-- Name: patients_id_seq; Type: SEQUENCE; Schema: public; Owner: oncology_user
--

CREATE SEQUENCE public.patients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.patients_id_seq OWNER TO oncology_user;

--
-- Name: patients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oncology_user
--

ALTER SEQUENCE public.patients_id_seq OWNED BY public.patients.id;


--
-- Name: medicines id; Type: DEFAULT; Schema: public; Owner: oncology_user
--

ALTER TABLE ONLY public.medicines ALTER COLUMN id SET DEFAULT nextval('public.medicines_id_seq'::regclass);


--
-- Name: patients id; Type: DEFAULT; Schema: public; Owner: oncology_user
--

ALTER TABLE ONLY public.patients ALTER COLUMN id SET DEFAULT nextval('public.patients_id_seq'::regclass);


--
-- Data for Name: medicines; Type: TABLE DATA; Schema: public; Owner: oncology_user
--

COPY public.medicines (id, name, description, quantity, created_at) FROM stdin;
1	Ibrutinib	For treating certain cancers, such as mantle cell lymphoma and chronic lymphocytic leukemia.	100	2025-08-13 12:59:47.251319+00
2	Trastuzumab	For treating HER2-positive breast cancer.	50	2025-08-13 12:59:47.251319+00
3	Letrozole	For treating breast cancer in postmenopausal women.	200	2025-08-13 12:59:47.251319+00
\.


--
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: oncology_user
--

COPY public.patients (id, first_name, last_name, date_of_birth, created_at) FROM stdin;
1	John	Doe	1975-04-12	2025-08-13 12:59:47.329089+00
2	Jane	Smith	1982-09-23	2025-08-13 12:59:47.329089+00
\.


--
-- Name: medicines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oncology_user
--

SELECT pg_catalog.setval('public.medicines_id_seq', 3, true);


--
-- Name: patients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oncology_user
--

SELECT pg_catalog.setval('public.patients_id_seq', 2, true);


--
-- Name: medicines medicines_pkey; Type: CONSTRAINT; Schema: public; Owner: oncology_user
--

ALTER TABLE ONLY public.medicines
    ADD CONSTRAINT medicines_pkey PRIMARY KEY (id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: oncology_user
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

